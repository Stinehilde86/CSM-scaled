/* global React, ReactDOM */
const { useEffect, useMemo, useState } = React;

// ---- Types (JSDoc for clarity) ----
// Project: { id, project, customer, segment, startDate, deadline, objective, owner, status, nextStep, risk, notes }

const SAMPLE = [
  {
    id: crypto.randomUUID(),
    project: "API-integrasjon HR-data",
    customer: "Kunde X",
    segment: "Enterprise",
    startDate: "2025-08-01",
    deadline: "2025-09-15",
    objective: "Få API-data inn i Power BI",
    owner: "Stine",
    status: "Pågår",
    nextStep: "Teste kobling uke 33",
    risk: "Mangler IT-tilgang",
    notes: "Avventer godkjenning",
  },
  {
    id: crypto.randomUUID(),
    project: "Aktivering onboarding-modul",
    customer: "Kunde Y",
    segment: "Mid-market",
    startDate: "2025-07-10",
    deadline: "2025-08-20",
    objective: "Øke bruk av onboarding",
    owner: "Stine",
    status: "På vent",
    nextStep: "Workshop 19.08",
    risk: "Ferie hos prosjektleder",
  },
  {
    id: crypto.randomUUID(),
    project: "Datahygiene og SSO",
    customer: "Kunde Z",
    segment: "SMB",
    startDate: "2025-06-05",
    deadline: "2025-07-05",
    objective: "Rydde brukere + aktivere SSO",
    owner: "Stine",
    status: "Fullført",
    nextStep: "Overvåke pålogging",
  },
];

function cx(...xs){ return xs.filter(Boolean).join(" "); }

function daysUntil(dateStr){
  if(!dateStr) return null;
  const d = new Date(`${dateStr}T00:00:00`);
  if(Number.isNaN(d.getTime())) return null;
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const diff = d.getTime() - today.getTime();
  return Math.floor(diff / (1000*60*60*24));
}

function deadlineTone(dateStr){
  const du = daysUntil(dateStr);
  if(du === null) return { tone: "none", className: "", du: null };
  if(du < 0) return { tone: "overdue", className: "chip overdue", du };
  if(du < 7) return { tone: "soon", className: "chip soon", du };
  return { tone: "ok", className: "chip ok", du };
}

function sortBy(arr, key, dir="asc"){
  const a = [...arr];
  a.sort((x,y)=>{
    const xv = (x?.[key] ?? "").toString().toLowerCase();
    const yv = (y?.[key] ?? "").toString().toLowerCase();
    if(xv < yv) return dir==="asc" ? -1: 1;
    if(xv > yv) return dir==="asc" ? 1: -1;
    return 0;
  });
  return a;
}

function useLocalStorage(key, initial){
  const [state, setState] = useState(()=>{
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : initial;
    }catch{ return initial; }
  });
  useEffect(()=>{
    try{ localStorage.setItem(key, JSON.stringify(state)); }catch{}
  }, [key, state]);
  return [state, setState];
}

function App(){
  const [projects, setProjects] = useLocalStorage("csm-projects", SAMPLE);
  const [query, setQuery] = useLocalStorage("csm-q", "");
  const [statusFilter, setStatusFilter] = useLocalStorage("csm-status", "alle");
  const [ownerFilter, setOwnerFilter] = useLocalStorage("csm-owner", "");
  const [sort, setSort] = useLocalStorage("csm-sort", {key: "deadline", dir: "asc"});
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  // Bind header buttons (outside React tree)
  useEffect(()=>{
    const btnNew = document.getElementById("btn-new");
    const btnExport = document.getElementById("btn-export");
    const h = ()=>{ setEditing(null); setModalOpen(true); };
    const ex = ()=> exportCSV(filtered);
    btnNew.addEventListener("click", h);
    btnExport.addEventListener("click", ex);
    return ()=>{
      btnNew.removeEventListener("click", h);
      btnExport.removeEventListener("click", ex);
    };
  }, []);

  // Bind filters (outside React)
  useEffect(()=>{
    const fq = document.getElementById("filter-q");
    const fs = document.getElementById("filter-status");
    const fo = document.getElementById("filter-owner");
    fq.value = query || "";
    fs.value = statusFilter || "alle";
    fo.value = ownerFilter || "";
    const onQ = (e)=> setQuery(e.target.value);
    const onS = (e)=> setStatusFilter(e.target.value);
    const onO = (e)=> setOwnerFilter(e.target.value);
    fq.addEventListener("input", onQ);
    fs.addEventListener("change", onS);
    fo.addEventListener("input", onO);
    return ()=>{
      fq.removeEventListener("input", onQ);
      fs.removeEventListener("change", onS);
      fo.removeEventListener("input", onO);
    };
  }, [query, statusFilter, ownerFilter, setQuery, setStatusFilter, setOwnerFilter]);

  const filtered = useMemo(()=>{
    const q = (query||"").trim().toLowerCase();
    let list = projects.filter(p=>{
      const inText = [p.project, p.customer, p.segment, p.objective, p.owner, p.nextStep, p.risk, p.notes]
        .filter(Boolean).join(" ").toLowerCase().includes(q);
      const statusOk = statusFilter === "alle" ? true : p.status === statusFilter;
      const ownerOk = ownerFilter ? (p.owner||"").toLowerCase().includes(ownerFilter.toLowerCase()) : true;
      return inText && statusOk && ownerOk;
    });
    if(sort?.key) list = sortBy(list, sort.key, sort.dir);
    return list;
  }, [projects, query, statusFilter, ownerFilter, sort]);

  // Counters
  const counts = useMemo(()=>{
    const by = {"Ikke startet":0, "Pågår":0, "På vent":0, "Fullført":0};
    projects.forEach(p=> by[p.status] += 1);
    return { all: projects.length, by };
  }, [projects]);

  // Update counters DOM (kept simple)
  useEffect(()=>{
    const elTotal = document.getElementById("count-total");
    const elNS = document.getElementById("c-notstarted");
    const elOn = document.getElementById("c-on");
    const elWait = document.getElementById("c-wait");
    const elDone = document.getElementById("c-done");
    if(elTotal) elTotal.textContent = String(counts.all);
    const badges = document.querySelectorAll(".badge-row .badge");
    if(badges[0]) badges[0].textContent = `Ikke startet: ${counts.by["Ikke startet"]}`;
    if(badges[1]) badges[1].textContent = `Pågår: ${counts.by["Pågår"]}`;
    if(badges[2]) badges[2].textContent = `På vent: ${counts.by["På vent"]}`;
    if(badges[3]) badges[3].textContent = `Fullført: ${counts.by["Fullført"]}`;
  }, [counts]);

  function remove(id){
    setProjects(prev => prev.filter(p=> p.id !== id));
  }

  function save(form){
    if(editing){
      setProjects(prev => prev.map(p => p.id === editing.id ? {...editing, ...form} : p));
    }else{
      const newP = {
        id: crypto.randomUUID(),
        project: (form.project||"Nytt prosjekt").trim(),
        customer: (form.customer||"").trim(),
        segment: (form.segment||"").trim(),
        startDate: form.startDate||"",
        deadline: form.deadline||"",
        objective: (form.objective||"").trim(),
        owner: (form.owner||"").trim(),
        status: form.status || "Ikke startet",
        nextStep: form.nextStep||"",
        risk: form.risk||"",
        notes: form.notes||"",
      };
      setProjects(prev => [newP, ...prev]);
    }
    setEditing(null);
    setModalOpen(false);
  }

  function onSort(key){
    setSort(s => s && s.key === key ? {key, dir: s.dir === "asc" ? "desc" : "asc"} : {key, dir:"asc"});
  }

  return (
    <React.Fragment>
      <Table
        rows={filtered}
        onSort={onSort}
        sort={sort}
        onEdit={(p)=>{ setEditing(p); setModalOpen(true);}}
        onDelete={remove}
      />
      {modalOpen && (
        <EditorModal
          initial={editing}
          onClose={()=> { setModalOpen(false); setEditing(null);}}
          onSave={save}
        />
      )}
    </React.Fragment>
  );
}

function HeaderSort({label, active, dir, onClick}){
  return <button className={cx("th-sort", active && "active", active && dir)} onClick={onClick}>{label}</button>;
}

function Table({rows, onSort, sort, onEdit, onDelete}){
  useEffect(()=>{
    const buttons = document.querySelectorAll('th .th-sort');
    buttons.forEach(btn=>{
      const key = btn.getAttribute('data-key');
      if(key){
        // handled by React via props in index.html; no-op
      }
    });
  }, []);

  // Render rows into tbody
  useEffect(()=>{
    const tbody = document.getElementById("tbody");
    if(!tbody) return;
    tbody.innerHTML = "";
    if(rows.length === 0){
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 11;
      td.className = "empty";
      td.textContent = "Ingen prosjekter matcher filtrene.";
      tr.appendChild(td);
      tbody.appendChild(tr);
      return;
    }
    rows.forEach(p=>{
      const tr = document.createElement("tr");

      const tdProj = document.createElement("td");
      tdProj.className = "minw";
      tdProj.textContent = p.project;
      tr.appendChild(tdProj);

      const tdCust = document.createElement("td");
      tdCust.textContent = p.segment ? `${p.customer} (${p.segment})` : (p.customer||"");
      tr.appendChild(tdCust);

      const tdStart = document.createElement("td");
      tdStart.textContent = p.startDate || "–";
      tr.appendChild(tdStart);

      const tdDeadline = document.createElement("td");
      if(p.deadline){
        const span = document.createElement("span");
        const tone = deadlineTone(p.deadline);
        span.className = tone.className;
        const du = tone.du;
        span.textContent = `${p.deadline}${typeof du === "number" ? ` (${du} d)` : ""}`;
        tdDeadline.appendChild(span);
      }else{
        tdDeadline.textContent = "–";
      }
      tr.appendChild(tdDeadline);

      const tdObj = document.createElement("td");
      tdObj.textContent = p.objective || "";
      tr.appendChild(tdObj);

      const tdOwner = document.createElement("td");
      tdOwner.textContent = p.owner || "";
      tr.appendChild(tdOwner);

      const tdStatus = document.createElement("td");
      const st = document.createElement("span");
      st.className = "badge " + (
        p.status === "Pågår" ? "badge-on" :
        p.status === "På vent" ? "badge-wait" :
        p.status === "Fullført" ? "badge-done" : ""
      );
      st.textContent = p.status;
      tdStatus.appendChild(st);
      tr.appendChild(tdStatus);

      const tdNext = document.createElement("td");
      tdNext.textContent = p.nextStep || "–";
      tr.appendChild(tdNext);

      const tdRisk = document.createElement("td");
      tdRisk.textContent = p.risk || "–";
      tr.appendChild(tdRisk);

      const tdNotes = document.createElement("td");
      tdNotes.textContent = p.notes || "–";
      tr.appendChild(tdNotes);

      const tdAct = document.createElement("td");
      tdAct.className = "text-right";
      const btnE = document.createElement("button");
      btnE.className = "icon-btn"; btnE.textContent = "✏️ Rediger";
      btnE.addEventListener("click", ()=> onEdit(p));
      const btnD = document.createElement("button");
      btnD.className = "icon-btn"; btnD.textContent = "🗑️ Slett";
      btnD.addEventListener("click", ()=> onDelete(p.id));
      tdAct.append(btnE, btnD);
      tr.appendChild(tdAct);

      tbody.appendChild(tr);
    });

  }, [rows, onEdit, onDelete]);

  // Bind column header sort buttons
  useEffect(()=>{
    const thButtons = document.querySelectorAll(".table thead .th-sort");
    const handle = (e)=>{
      const key = e.currentTarget.dataset.key;
      if(key) onSort(key);
    };
    thButtons.forEach(btn=>{
      btn.addEventListener("click", handle);
      // toggle active state
      const key = btn.getAttribute("data-key");
      btn.classList.toggle("active", sort?.key === key);
      btn.classList.toggle("asc", sort?.key === key && sort?.dir === "asc");
      btn.classList.toggle("desc", sort?.key === key && sort?.dir === "desc");
    });
    return ()=> thButtons.forEach(btn=> btn.removeEventListener("click", handle));
  }, [onSort, sort]);

  return null;
}

function EditorModal({initial, onClose, onSave}){
  useEffect(()=>{
    const $ = id => document.getElementById(id);
    $("#f-project").value = initial?.project ?? "";
    $("#f-customer").value = initial?.customer ?? "";
    $("#f-segment").value = initial?.segment ?? "";
    $("#f-owner").value = initial?.owner ?? "Stine";
    $("#f-start").value = initial?.startDate ?? "";
    $("#f-deadline").value = initial?.deadline ?? "";
    $("#f-objective").value = initial?.objective ?? "";
    $("#f-status").value = initial?.status ?? "Ikke startet";
    $("#f-next").value = initial?.nextStep ?? "";
    $("#f-risk").value = initial?.risk ?? "";
    $("#f-notes").value = initial?.notes ?? "";
  }, [initial]);

  useEffect(()=>{
    const modal = document.getElementById("modal");
    const onKey = (e)=>{ if(e.key === "Escape") onClose(); };
    const cancel = document.getElementById("btn-cancel");
    const save = document.getElementById("btn-save");
    const onCancel = ()=> onClose();
    const onSaveClick = ()=>{
      const $ = id => document.getElementById(id);
      const vals = {
        project: $("#f-project").value,
        customer: $("#f-customer").value,
        segment: $("#f-segment").value,
        owner: $("#f-owner").value,
        startDate: $("#f-start").value,
        deadline: $("#f-deadline").value,
        objective: $("#f-objective").value,
        status: $("#f-status").value,
        nextStep: $("#f-next").value,
        risk: $("#f-risk").value,
        notes: $("#f-notes").value,
      };
      onSave(vals);
    };
    modal.classList.remove("hidden");
    document.addEventListener("keydown", onKey);
    cancel.addEventListener("click", onCancel);
    save.addEventListener("click", onSaveClick);
    return ()=>{
      modal.classList.add("hidden");
      document.removeEventListener("keydown", onKey);
      cancel.removeEventListener("click", onCancel);
      save.removeEventListener("click", onSaveClick);
    };
  }, [onClose, onSave]);

  return null;
}

function exportCSV(rows){
  const cols = ["project","customer","segment","startDate","deadline","objective","owner","status","nextStep","risk","notes"];
  const header = cols.join(",");
  const lines = rows.map(p=> cols.map(c=> `"${String(p[c] ?? "").replaceAll('"','""')}"`).join(",") );
  const csv = [header, ...lines].join("\n");
  const blob = new Blob([csv], {type: "text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `prosjekter-${new Date().toISOString().slice(0,10)}.csv`; a.click();
  URL.revokeObjectURL(url);
}

// ---- Render ----
ReactDOM.createRoot(document.getElementById("tbody")?.closest("main") || document.body).render(<App />);

// ---- Simple runtime tests (console) ----
(function runTests(){
  try{
    console.assert(daysUntil("2099-01-01") !== null, "daysUntil should parse date");
    console.assert(deadlineTone("1999-01-01").tone === "overdue", "past date should be overdue");
    console.assert(["soon","ok"].includes(deadlineTone("2099-01-01").tone), "future date ok/soon");
    const sorted = sortBy([{project:"b"},{project:"a"}],"project","asc");
    console.assert(sorted[0].project === "a", "sort asc");
  }catch(e){
    console.error("Runtime tests failed:", e);
  }
})();